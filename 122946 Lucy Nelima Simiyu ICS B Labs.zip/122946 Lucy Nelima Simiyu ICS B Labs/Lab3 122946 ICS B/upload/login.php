<?php
$conn = new mysqli("localhost", "root", "");
$conn->select_db("labtwo");
session_start();
if (isset($_POST['username'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
        $query = $conn->query("select username from user where username = '$username' and password ='$password'");
        if ($query->num_rows === 1) {
            $_SESSION['user'] = $username;
            echo "login";
        } else {
            echo "Username and Password is incorrect";
        }
}

?>
    