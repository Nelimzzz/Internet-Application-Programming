<!DOCTYPE html>
<html lang="en">
<head>
<title></title>
    <meta charset="UTF-8">
    <script src="js/main.js" type = text/javascript></script>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous" type=text/javascript></script>
    <link rel="stylesheet" href="ccs/style.css" type="text">
</head>
<body>  
<div id="body-container">
            <div id="mybtn">
                <a href="#" onclick="contact_us_page();">Contact us</a>
                <a href="#" onclick="signup_page();">My Account</a>
            </div>
            <div id="page">
                <h3>Homepage</h3>
            </div>
        </div>
    
</body>
</html>