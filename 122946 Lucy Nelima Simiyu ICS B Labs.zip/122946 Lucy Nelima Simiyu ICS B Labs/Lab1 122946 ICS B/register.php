<? php include('functions.php')?>
<!DOCTYPE html>
<html >
<head> 
    <title>Register</title>
    <link rel="stylesheet" href="reg.css">
</head>
<body>
    <div class="header">
    <h1>Register</h1>
    </div>
    <form method = "post" action="process_register.php">
   
        <div class="input-group">
        <label>Username</label>
		<input type="text" name="username" placeholder = " Enter names" >
	</div>
	<div class="input-group">
		<label>Email</label>
		<input type="email" name="email"  placeholder = " Enter email" >
	</div>
	<div class="input-group">
		<label>Password</label>
		<input type="password" name="password_1" >
	</div>
	<div class="input-group">
		<label>Confirm password</label>
		<input type="password" name="password_2" >
	</div>
	<div class="input-group">
		<button type="submit" class="btn" name="register_btn">Register</button>
	</div>
    <p>
		Already a member? <a href="login.php">Sign in</a>
	</p>
        
         </form>
    
</body>
</html>