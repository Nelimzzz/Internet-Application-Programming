<?php   
class Conn{
     static $dbserver = "localhost";
     static $dbname = "project";
     static $dbuser= "root";
     static $password = "";
}?>